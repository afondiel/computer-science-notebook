/*****************************************************************************************************/
/*												     */									
/*   Fichiers:  kruskal.c dijkstra.c graphe_no.txt graphe_o.txt					     */
/*   Version: 	2						     				     */
/*   Date:    	02/12/2015									     */
/*   Auteurs:   Afonso DIELA - Badr GHANMI | afonso.diela@ensea.fr - badr.ghanmi@ensea.fr 	     */
/*   But :	algorithme de Kruskal et Dijkstra						     */
/*   Mati�re :  Algorithmique | structure de donn�e | th�orie des graphes 			     */
/*												     */
/*****************************************************************************************************/


INTRO : 
********

Dans ce projet on d�veloppe deux algorithmes :

-*Kruskal : qui consiste � calculer le poid minimum d'un arbre.

-*Dijkstra :  dont le but est de calculer la longueur du chemin le plus court.

Cette version 2, c'est la mise � jour de la version pr�cendente am�lior�e pour les deux algos.













 

/*----------------------------------------------------------------------------------------------------*/
